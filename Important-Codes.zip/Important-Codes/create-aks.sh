#!/bin/bash

echo "Let's get started with Kubernetes cluster creation using AKS!"
echo "Enter your name:"
read username
lower_username=$(echo -e $username | sed 's/ //g' | tr '[:upper:]' '[:lower:]')
date_now=$(date "+%F-%H-%M")
clname=$(echo $lower_username-$date_now-aks)
rgname=$(echo $lower_username-rg)

echo "Your Kubernetes cluster name will be $clname"
echo "Resource group will be $rgname"

# Update system
sudo apt update -y
sudo apt install -y curl nano python3-pip apt-transport-https

# Install Azure CLI
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash

# Install kubectl
sudo az aks install-cli

# Login to Azure (interactive)
echo "Please login to Azure..."
az login

# Create resource group
az group create --name $rgname --location eastus

# Create AKS cluster
az aks create \
  --resource-group $rgname \
  --name $clname \
  --node-count 2 \
  --node-vm-size Standard_B2s \
  --enable-addons monitoring \
  --generate-ssh-keys

# Get credentials for kubectl
az aks get-credentials --resource-group $rgname --name $clname

# Validate cluster
for (( x=0 ; x < 30 ; x++ )); do
  echo "Validating Cluster"
  if kubectl get nodes | grep -q "Ready"; then
    echo "Your AKS Cluster is now ready!"
    break
  else
    sleep 20
    echo "x: $x"
  fi
done
